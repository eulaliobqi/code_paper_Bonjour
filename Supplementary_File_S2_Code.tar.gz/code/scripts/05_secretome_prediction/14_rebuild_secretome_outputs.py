#!/usr/bin/env python3
import argparse, re
from pathlib import Path
import pandas as pd

def read_any(p: Path):
    for sep in [",",";","\t"]:
        try:
            df = pd.read_csv(p, dtype=str, sep=sep)
            if df.shape[1] >= 1:
                return df
        except Exception:
            pass
    return pd.read_csv(p, dtype=str)

def parse_signalp_out_all(path: Path) -> pd.DataFrame:
    rows = []
    for ln in path.read_text().splitlines():
        if not ln.strip():
            continue
        parts = ln.split("\t")
        pid  = parts[0].strip()
        pred = parts[1].strip() if len(parts) > 1 else ""
        probO = parts[2].strip() if len(parts) > 2 else ""
        probSP= parts[3].strip() if len(parts) > 3 else ""
        cs = ""
        pr = ""
        m_cs = re.search(r"CS pos:\s*([0-9]+-[0-9]+)", ln)
        if m_cs: cs = m_cs.group(1)
        m_pr = re.search(r"Pr:\s*([0-9.]+)", ln)
        if m_pr: pr = m_pr.group(1)
        rows.append([pid, "Y" if pred.upper()=="SP" else "N", probO, probSP, cs, pr])
    return pd.DataFrame(rows, columns=["ProteinID","SignalP_SP","Prob_OTHER","Prob_SP","SignalP_CS","SignalP_Pr"])

def yes(v): 
    return str(v).strip().upper().startswith("Y")

def s2i(x, default=0):
    try: 
        return int(float(x))
    except Exception: 
        return default

def add_annotations(dfin: pd.DataFrame, ann_df: pd.DataFrame) -> pd.DataFrame:
    gene_pat = re.compile(r'Gene[._-]?(\d+)', re.I)
    def gene_norm(s):
        m = gene_pat.search(str(s)); return f"Gene_{m.group(1)}" if m else ""
    df = dfin.copy()
    df["gene_key_norm"] = df["ProteinID"].map(gene_norm)

    if "gene_key_norm" not in ann_df.columns:
        if "Gene_equivalente" in ann_df.columns:
            ann_df = ann_df.assign(gene_key_norm=ann_df["Gene_equivalente"].map(gene_norm))
        elif "gene_key" in ann_df.columns:
            ann_df = ann_df.assign(gene_key_norm=ann_df["gene_key"].map(gene_norm))
        else:
            cands = [c for c in ann_df.columns if "gene" in c.lower()]
            if cands:
                ann_df = ann_df.assign(gene_key_norm=ann_df[cands[0]].map(gene_norm))
            else:
                ann_df = ann_df.assign(gene_key_norm="")

    cols_annot = [c for c in ["GO_annotation","KEGG_annotation","Pfam_annotation",
                              "Swissprot_annotation","TrEMBL_annotation","nr_annotation"]
                  if c in ann_df.columns]
    ann_sub = ann_df[["gene_key_norm"]+cols_annot].copy()

    out = df.merge(ann_sub, on="gene_key_norm", how="left").drop(columns=["gene_key_norm"])
    return out

def main():
    ap = argparse.ArgumentParser(description="Rebuild secretome outputs (SignalP + Phobius + optional annotation).")
    ap.add_argument("--signalp-out", required=True, help="signalp_out_all.txt (resumo por sequência)")
    ap.add_argument("--phobius",     required=True, help="phobius_parsed.csv (ou TSV/CSV com colunas compatíveis)")
    ap.add_argument("--ann",         default=None,  help="Tabela mestre de anotação (All_Database_annotation_*.csv)")
    ap.add_argument("--outprefix",   default="secretome_validation_fix", help="Prefixo dos arquivos de saída")
    args = ap.parse_args()

    signalp_out = Path(args.signalp_out)
    phobius_p   = Path(args.phobius)
    ann_p       = Path(args.ann) if args.ann else None

    # --- SignalP ---
    sp = parse_signalp_out_all(signalp_out)
    sp = sp.rename(columns={sp.columns[0]:"ProteinID"})
    if "SignalP_SP" not in sp.columns:
        sp["SignalP_SP"] = "N"
    if "SignalP_CS" not in sp.columns:
        cs_cols = [c for c in sp.columns if "CS" in c]
        sp["SignalP_CS"] = sp[cs_cols[0]] if cs_cols else ""

    # --- Phobius ---
    pho = read_any(phobius_p).copy()
    pho = pho.rename(columns={pho.columns[0]:"ProteinID"})
    if "Phobius_SP" not in pho.columns and "SP" in pho.columns:
        pho["Phobius_SP"] = pho["SP"]
    if "Phobius_TMs" not in pho.columns and "#TM" in pho.columns:
        pho["Phobius_TMs"] = pho["#TM"]
    pho["Phobius_TMs"] = pd.to_numeric(pho.get("Phobius_TMs", 0), errors="coerce").fillna(0).astype(int)

    # --- Merge + consenso ---
    keep_pho = [c for c in ["ProteinID","Phobius_TMs","Phobius_SP","Phobius_prediction"] if c in pho.columns]
    df = sp.merge(pho[keep_pho], on="ProteinID", how="outer")

    def consensus(row):
        sp_ok  = yes(row.get("SignalP_SP","N"))
        pho_ok = yes(row.get("Phobius_SP","N"))
        tmn    = s2i(row.get("Phobius_TMs", 0))
        if sp_ok and (pho_ok or tmn <= 1): return "High"
        if sp_ok or pho_ok:                return "Medium"
        return "Low"

    if "Phobius_TMs" not in df.columns:
        df["Phobius_TMs"] = 0
    df["TM_n"] = df["Phobius_TMs"].apply(s2i)
    df["Export_consensus"] = df.apply(consensus, axis=1)

    # --- Saídas principais ---
    out_all = Path(f"{args.outprefix}_all_predictions.csv")
    out_sp  = Path(f"{args.outprefix}_SignalP_pos.csv")
    out_hi  = Path(f"{args.outprefix}_consensus_high.csv")
    out_mh  = Path(f"{args.outprefix}_consensus_med_high.csv")

    df.to_csv(out_all, index=False)
    df[df["SignalP_SP"].apply(yes)].to_csv(out_sp, index=False)
    df[df["Export_consensus"].eq("High")].to_csv(out_hi, index=False)
    df[df["Export_consensus"].isin(["High","Medium"])].to_csv(out_mh, index=False)

    print("Salvos (sem anotação):")
    for p in [out_all, out_sp, out_hi, out_mh]:
        print(" -", p)

    # --- Anotação (opcional) ---
    if ann_p and ann_p.exists():
        # detectar separador pela 1ª linha
        with ann_p.open('r', encoding='utf-8', errors='ignore') as f:
            header = f.readline().rstrip('\n')
        sep = max([';','\t',','], key=lambda d: header.count(d))
        ann = pd.read_csv(ann_p, sep=sep, dtype=str, low_memory=False)

        out_all_ann = Path(f"{args.outprefix}_all_predictions_with_ann.csv")
        out_sp_ann  = Path(f"{args.outprefix}_SignalP_pos_with_ann.csv")
        out_hi_ann  = Path(f"{args.outprefix}_consensus_high_with_ann.csv")
        out_mh_ann  = Path(f"{args.outprefix}_consensus_med_high_with_ann.csv")

        add_annotations(df, ann).to_csv(out_all_ann, index=False)
        add_annotations(df[df["SignalP_SP"].apply(yes)], ann).to_csv(out_sp_ann, index=False)
        add_annotations(df[df["Export_consensus"].eq("High")], ann).to_csv(out_hi_ann, index=False)
        add_annotations(df[df["Export_consensus"].isin(["High","Medium"])], ann).to_csv(out_mh_ann, index=False)

        print("Salvos (com anotação):")
        for p in [out_all_ann, out_sp_ann, out_hi_ann, out_mh_ann]:
            print(" -", p)
    else:
        print("Obs.: arquivo de anotação não fornecido (use --ann para gerar as versões *_with_ann.csv).")

    # resumo
    n_all = len(df)
    n_sp  = int(df["SignalP_SP"].apply(yes).sum())
    n_hi  = int((df["Export_consensus"]=="High").sum())
    n_mh  = int(df["Export_consensus"].isin(["High","Medium"]).sum())
    print(f"Resumo -> N_total={n_all} | SP+= {n_sp} | High={n_hi} | Med+High={n_mh}")

if __name__ == "__main__":
    main()
