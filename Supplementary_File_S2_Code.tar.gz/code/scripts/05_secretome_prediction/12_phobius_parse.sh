#!/usr/bin/env bash
set -euo pipefail

IN_TXT="${1:?Provide phobius_short.txt}"
OUT_PREFIX="${2:?Provide output prefix}"

tail -n +2 "$IN_TXT" | tr -s ' ' | tr ' ' '\t' > "${OUT_PREFIX}.tsv"

awk -F'\t' 'BEGIN{OFS=","; print "ProteinID,Phobius_TMs,Phobius_SP,Phobius_prediction"}
{print $1,$2,$3,$4}' "${OUT_PREFIX}.tsv" > "${OUT_PREFIX}.csv"
