# Code availability – Secretome prediction

This package contains all scripts used for signal peptide and transmembrane domain
prediction, as well as the integration of SignalP and Phobius outputs to define
consensus secreted protein sets.

## Software and versions
- Phobius v1.01 (local installation)
- SignalP v6.0 (eukaryote model, default parameters)
- Python >= 3.8
- Perl >= 5

## Input data
- Protein FASTA file derived from RNA-seq assembly and ORF prediction
  (e.g. proteins_Batelli_02_09_2025.fasta)

## Step-by-step workflow

### 1) Phobius prediction (transmembrane domains and signal peptides)
Run Phobius locally using default parameters:

bash scripts/05_secretome_prediction/11_phobius_run.sh proteins.fasta phobius_short.txt

### 2) Parse Phobius output
Convert Phobius short output into tabular format:

bash scripts/05_secretome_prediction/12_phobius_parse.sh phobius_short.txt phobius

### 3) SignalP prediction
Signal peptide prediction was performed using SignalP 6.0 with default parameters
(eukaryote model). Depending on the execution mode, one of the following output files
was generated and used as input for integration:
- signalp_summary_parsed.csv
- signalp_parsed.csv
- signalp_out_all.txt

### 4) Integration of SignalP and Phobius predictions
SignalP and Phobius outputs were integrated using a custom Python script.

## Notes
All analyses were performed using default parameters unless otherwise stated.
