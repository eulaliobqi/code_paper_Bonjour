#!/bin/bash
set -euo pipefail

# 06_misa_ssr.sh
# SSR detection using MISA (mono- to hexanucleotide + compound repeats)
# Requirements: perl, MISA (misa.pl in PATH or current directory)
#
# Usage:
#   bash 06_misa_ssr.sh trinity_out_dir/Trinity.fasta /path/to/misa.pl

FASTA="${1:-trinity_out_dir/Trinity.fasta}"
MISA_PL="${2:-misa.pl}"

# Create misa.ini with parameters (as provided)
cat > misa.ini <<'EOF'
definition_file=
min_repeats=10 6 5 5 5 5
interruptions=100
EOF

perl "${MISA_PL}" "${FASTA}"
