# Supplementary File S2 – Alternative splicing analysis (Trinity isoform structure)

This package contains custom Python scripts used to assess transcriptome complexity arising from alternative splicing (AS) based on Trinity isoform structure (Section 2.8 of the manuscript).
In Trinity nomenclature, transcripts sharing the same gene identifier (e.g., TRINITY_DNxxxxx_cY_gZ) but distinct isoform suffixes (i1, i2, ...) are considered isoforms of a single unigene cluster.

## Software
- Python 3.10 (or compatible Python >= 3.8)

## Core input
- Trinity transcript FASTA file (e.g., Demo.Transcripts.fa)

## Optional inputs for integration (as used in the manuscript)
- Pfam annotation table (tsv/csv) containing a Trinity gene identifier column
- KEGG/KAAS annotation table (tsv/csv) containing a Trinity gene identifier column
- Expression table (tsv/csv) containing gene-level expression (FPKM) and a Trinity gene identifier column

## Outputs
- isoform_counts.tsv: isoform counts per Trinity gene
- isoform_stats.json: descriptive statistics (total genes, max/average isoforms per gene, fraction of multi-isoform loci)
- isoform_stats_frequency.tsv: frequency distribution of isoform counts
- merged tables integrating isoform counts with Pfam/KEGG/FPKM (optional steps)
- category assignment and summary tables reporting AS fraction per functional category

## Workflow

1) Count isoforms per Trinity gene
python scripts/01_isoform_parsing/count_trinity_isoforms.py --fasta Demo.Transcripts.fa --out isoform_counts.tsv

2) Compute descriptive statistics and isoform count frequency distribution
python scripts/02_statistics/isoform_stats.py --counts isoform_counts.tsv --out-prefix isoform_stats

3) Merge isoform counts with Pfam/KEGG annotations (optional integration)
python scripts/03_functional_integration/merge_isoforms_annotations.py --counts isoform_counts.tsv --annotation pfam.tsv --id-col GeneID --out merged_pfam.tsv
python scripts/03_functional_integration/merge_isoforms_annotations.py --counts isoform_counts.tsv --annotation kegg.tsv --id-col GeneID --out merged_kegg.tsv

4) Merge isoform counts with gene-level expression (FPKM) (optional integration)
python scripts/04_expression_integration/merge_isoforms_expression.py --counts isoform_counts.tsv --expression expression.tsv --id-col GeneID --expr-col FPKM --out merged_expression.tsv

5) Functional category assignment and AS fraction per category (using curated regex rules)
python scripts/03_functional_integration/classify_as_categories.py --pfam merged_pfam.tsv --kegg merged_kegg.tsv --rules config/category_rules.yaml --out-prefix as_by_category

## Notes
- Genes with >= 2 isoforms are defined as multi-isoform loci and considered potential AS candidates, consistent with the Methods section.
- Category assignment uses curated regex patterns stored in config/category_rules.yaml; edit patterns to match your final curation terms.
