#!/bin/bash
set -euo pipefail

# 03_fastqc_trimmed.sh
# QC of trimmed reads
# Requirements: fastqc
#
# Usage:
#   bash 03_fastqc_trimmed.sh data_1_clean.fq.gz data_2_clean.fq.gz

R1_CLEAN="${1:-data_1_clean.fq.gz}"
R2_CLEAN="${2:-data_2_clean.fq.gz}"

THREADS="${THREADS:-20}"
OUTDIR="${OUTDIR:-fastqc_trimmed}"

mkdir -p "${OUTDIR}"
fastqc -t "${THREADS}" -o "${OUTDIR}" "${R1_CLEAN}" "${R2_CLEAN}"
