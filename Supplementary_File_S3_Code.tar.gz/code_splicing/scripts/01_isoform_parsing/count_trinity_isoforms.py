#!/usr/bin/env python3
import argparse
import re
from pathlib import Path
from collections import defaultdict

TRINITY_GENE_RE = re.compile(r'^(TRINITY_[^ ]+_g\d+)')

def parse_fasta_headers(fasta_path: Path):
    with fasta_path.open('r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if line.startswith('>'):
                yield line[1:].strip()

def infer_gene_id(header: str) -> str:
    m = TRINITY_GENE_RE.search(header)
    if not m:
        return header.split()[0]
    return m.group(1)

def main():
    ap = argparse.ArgumentParser(description='Count Trinity isoforms per gene from transcript FASTA.')
    ap.add_argument('--fasta', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()

    fasta = Path(args.fasta)
    if not fasta.exists():
        raise FileNotFoundError(f'FASTA not found: {fasta}')

    counts = defaultdict(int)
    seen = set()
    for h in parse_fasta_headers(fasta):
        tid = h.split()[0]
        if tid in seen:
            continue
        seen.add(tid)
        gid = infer_gene_id(tid)
        counts[gid] += 1

    outp = Path(args.out)
    outp.parent.mkdir(parents=True, exist_ok=True)
    with outp.open('w', encoding='utf-8') as w:
        w.write('GeneID\tIsoformCount\tMultiIsoform\n')
        for gid in sorted(counts):
            c = counts[gid]
            w.write(f'{gid}\t{c}\t{1 if c>=2 else 0}\n')

    print(f'OK: wrote {outp} (genes={len(counts)})')

if __name__ == '__main__':
    main()
