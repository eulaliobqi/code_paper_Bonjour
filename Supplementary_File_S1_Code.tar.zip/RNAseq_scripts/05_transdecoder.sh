#!/bin/bash
set -euo pipefail

# 05_transdecoder.sh
# ORF / CDS prediction from Trinity assembly
# Requirements: TransDecoder
#
# Usage:
#   bash 05_transdecoder.sh trinity_out_dir/Trinity.fasta

TRINITY_FASTA="${1:-trinity_out_dir/Trinity.fasta}"

TransDecoder.LongOrfs -t "${TRINITY_FASTA}"
TransDecoder.Predict  -t "${TRINITY_FASTA}" --single_best_only
