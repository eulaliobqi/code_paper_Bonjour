#!/bin/bash
set -euo pipefail

# 01_fastqc_raw.sh
# Quality control of raw reads (Phred33)
# Requirements: fastqc
#
# Usage:
#   bash 01_fastqc_raw.sh data_1.fq.gz data_2.fq.gz

R1="${1:-data_1.fq.gz}"
R2="${2:-data_2.fq.gz}"

THREADS="${THREADS:-20}"
OUTDIR="${OUTDIR:-fastqc_raw}"

mkdir -p "${OUTDIR}"
fastqc -t "${THREADS}" -o "${OUTDIR}" "${R1}" "${R2}"
