#!/usr/bin/env bash
set -euo pipefail

export PHOBIUS_DIR="${PHOBIUS_DIR:-$HOME/tools/phobius}"

IN_FASTA="${1:?Provide input FASTA}"
OUT_TXT="${2:?Provide output txt}"

perl "$PHOBIUS_DIR/phobius.pl" -short "$IN_FASTA" > "$OUT_TXT"
