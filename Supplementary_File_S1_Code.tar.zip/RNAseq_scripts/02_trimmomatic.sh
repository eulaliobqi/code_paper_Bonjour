#!/bin/bash
set -euo pipefail

# 02_trimmomatic.sh
# Read trimming/filtering (Phred33, Q20, adapters, >10% Ns)
# Requirements: trimmomatic, adapter file (e.g., TruSeq3-PE.fa)
#
# Usage:
#   bash 02_trimmomatic.sh data_1.fq.gz data_2.fq.gz TruSeq3-PE.fa

R1="${1:-data_1.fq.gz}"
R2="${2:-data_2.fq.gz}"
ADAPTERS="${3:-TruSeq3-PE.fa}"

THREADS="${THREADS:-20}"

# Output names (you may change as needed)
R1_CLEAN="${R1_CLEAN:-data_1_clean.fq.gz}"
R1_UNCLEAN="${R1_UNCLEAN:-data_1_unclean.fq.gz}"
R2_CLEAN="${R2_CLEAN:-data_2_clean.fq.gz}"
R2_UNCLEAN="${R2_UNCLEAN:-data_2_unclean.fq.gz}"

trimmomatic PE -phred33 -threads "${THREADS}"   "${R1}" "${R2}"   "${R1_CLEAN}" "${R1_UNCLEAN}"   "${R2_CLEAN}" "${R2_UNCLEAN}"   "ILLUMINACLIP:${ADAPTERS}:2:30:10:2:keepBothReads"   LEADING:20 TRAILING:20 SLIDINGWINDOW:4:20 MINLEN:36
