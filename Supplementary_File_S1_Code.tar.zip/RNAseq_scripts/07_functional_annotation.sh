#!/bin/bash
set -euo pipefail

# 07_functional_annotation.sh
# Functional annotation: Pfam scan (hmmscan) and BLASTp
# Requirements: hmmscan (HMMER), Pfam-A.hmm, blastp, NR database (or other)
#
# Usage:
#   bash 07_functional_annotation.sh trinity_out_dir/Trinity.fasta.transdecoder.pep Pfam-A.hmm nr

PEP="${1:-trinity_out_dir/Trinity.fasta.transdecoder.pep}"
PFAM_HMM="${2:-Pfam-A.hmm}"
BLAST_DB="${3:-nr}"

CPU="${CPU:-16}"

# Pfam domains
hmmscan --cpu "${CPU}" --domtblout pfam.domtblout "${PFAM_HMM}" "${PEP}"

# BLASTp (note: in your original snippet the output name suggests a fasta; here we keep a standard tabular output)
blastp -query "${PEP}" -db "${BLAST_DB}"   -evalue 1e-5 -num_threads "${CPU}" -max_target_seqs 1 -outfmt 6   -out blastp_nr.outfmt6.tsv
