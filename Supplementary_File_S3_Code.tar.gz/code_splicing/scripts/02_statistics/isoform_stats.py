#!/usr/bin/env python3
import argparse, json
from pathlib import Path
from collections import Counter

def read_counts(path: Path):
    rows = []
    with path.open('r', encoding='utf-8', errors='ignore') as f:
        header = f.readline().rstrip('\n').split('\t')
        i_gene = header.index('GeneID')
        i_cnt = header.index('IsoformCount')
        for ln in f:
            if not ln.strip():
                continue
            parts = ln.rstrip('\n').split('\t')
            rows.append((parts[i_gene], int(float(parts[i_cnt]))))
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--counts', required=True)
    ap.add_argument('--out-prefix', required=True)
    args = ap.parse_args()

    rows = read_counts(Path(args.counts))
    vals = [c for _, c in rows]
    freq = Counter(vals)

    stats = {
        'total_genes': len(vals),
        'multi_isoform_genes_ge2': sum(1 for c in vals if c >= 2),
        'multi_isoform_fraction': (sum(1 for c in vals if c >= 2) / len(vals)) if vals else 0,
        'max_isoforms_per_gene': max(vals) if vals else 0,
        'average_isoforms_per_gene': (sum(vals) / len(vals)) if vals else 0,
    }

    outpref = Path(args.out_prefix)
    outpref.parent.mkdir(parents=True, exist_ok=True)
    (outpref.with_suffix('.json')).write_text(json.dumps(stats, indent=2), encoding='utf-8')

    freq_path = outpref.with_name(outpref.name + '_frequency.tsv')
    with freq_path.open('w', encoding='utf-8') as w:
        w.write('IsoformCount\tGenes\n')
        for k in sorted(freq):
            w.write(f'{k}\t{freq[k]}\n')

    print('OK:', stats)

if __name__ == '__main__':
    main()
