#!/bin/bash
set -euo pipefail

# 08_bowtie2_alignment.sh
# Bowtie2 indexing + alignment of cleaned reads to Trinity assembly
# Requirements: bowtie2, bowtie2-build
#
# Usage:
#   bash 08_bowtie2_alignment.sh trinity_out_dir/Trinity.fasta data_1_clean.fq.gz data_2_clean.fq.gz

TRINITY_FASTA="${1:-trinity_out_dir/Trinity.fasta}"
R1_CLEAN="${2:-data_1_clean.fq.gz}"
R2_CLEAN="${3:-data_2_clean.fq.gz}"

THREADS="${THREADS:-16}"
INDEX_PREFIX="${INDEX_PREFIX:-trinity_index}"
OUT_SAM="${OUT_SAM:-data_aligned.sam}"

# Build index
bowtie2-build "${TRINITY_FASTA}" "${INDEX_PREFIX}"

# Align
bowtie2 -x "${INDEX_PREFIX}" -1 "${R1_CLEAN}" -2 "${R2_CLEAN}"   -S "${OUT_SAM}" --threads "${THREADS}" --no-unal --quiet
