# RNA-Seq assembly and analysis scripts (review package)

This folder contains the command-line scripts used for the RNA-Seq processing, de novo transcriptome assembly, and downstream analyses.

## Contents
- `01_fastqc_raw.sh` – Quality control of raw reads (FastQC)
- `02_trimmomatic.sh` – Adapter trimming and quality filtering (Trimmomatic; Phred33; Q20)
- `03_fastqc_trimmed.sh` – Quality control of trimmed reads (FastQC)
- `04_trinity_assembly.sh` – De novo transcriptome assembly (Trinity)
- `05_transdecoder.sh` – ORF/CDS prediction (TransDecoder)
- `06_misa_ssr.sh` – SSR detection (MISA)
- `07_functional_annotation.sh` – Pfam domain scan (HMMER hmmscan) and BLASTp search
- `08_bowtie2_alignment.sh` – Bowtie2 indexing and alignment to the Trinity assembly
- `09_rsem_quantification.sh` – Expression quantification (RSEM + Bowtie2)

## Notes
- Scripts are provided **as executed** in the study. File names and paths may need minor adaptation to match your local environment.
- Multi-threading is controlled via environment variables (e.g., `THREADS`, `CPU`) where applicable.
- External resources required for annotation:
  - Pfam HMM database (e.g., `Pfam-A.hmm`)
  - BLAST protein database (e.g., `nr`)

## Example usage
```bash
bash 01_fastqc_raw.sh data_1.fq.gz data_2.fq.gz
bash 02_trimmomatic.sh data_1.fq.gz data_2.fq.gz TruSeq3-PE.fa
bash 03_fastqc_trimmed.sh data_1_clean.fq.gz data_2_clean.fq.gz
bash 04_trinity_assembly.sh data_1_clean.fq.gz data_2_clean.fq.gz
bash 05_transdecoder.sh trinity_out_dir/Trinity.fasta
bash 06_misa_ssr.sh trinity_out_dir/Trinity.fasta /path/to/misa.pl
bash 07_functional_annotation.sh trinity_out_dir/Trinity.fasta.transdecoder.pep Pfam-A.hmm nr
bash 08_bowtie2_alignment.sh trinity_out_dir/Trinity.fasta data_1_clean.fq.gz data_2_clean.fq.gz
bash 09_rsem_quantification.sh trinity_out_dir/Trinity.fasta data_1_clean.fq.gz data_2_clean.fq.gz
```

## Output highlights
- FastQC reports: `fastqc_raw/` and `fastqc_trimmed/`
- Trinity assembly: `trinity_out_dir/Trinity.fasta`
- TransDecoder peptides: `trinity_out_dir/Trinity.fasta.transdecoder.pep`
- Pfam results: `pfam.domtblout`
- BLASTp results: `blastp_nr.outfmt6.tsv`
- RSEM results: `data_expression.genes.results` and `data_expression.isoforms.results`
