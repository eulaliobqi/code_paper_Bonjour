#!/bin/bash
set -euo pipefail

# 04_trinity_assembly.sh
# De novo transcriptome assembly
# Requirements: Trinity
#
# Usage:
#   bash 04_trinity_assembly.sh data_1_clean.fq.gz data_2_clean.fq.gz

R1_CLEAN="${1:-data_1_clean.fq.gz}"
R2_CLEAN="${2:-data_2_clean.fq.gz}"

CPU="${CPU:-20}"
MAX_MEMORY="${MAX_MEMORY:-50G}"
OUTDIR="${OUTDIR:-trinity_out_dir}"
MIN_CONTIG_LEN="${MIN_CONTIG_LEN:-200}"

Trinity --seqType fq   --max_memory "${MAX_MEMORY}"   --CPU "${CPU}"   --left "${R1_CLEAN}"   --right "${R2_CLEAN}"   --output "${OUTDIR}"   --no_normalize_reads   --min_contig_length "${MIN_CONTIG_LEN}"
