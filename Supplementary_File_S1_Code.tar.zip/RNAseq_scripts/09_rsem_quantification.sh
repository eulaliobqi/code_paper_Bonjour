#!/bin/bash
set -euo pipefail

# 09_rsem_quantification.sh
# Expression quantification using RSEM + Bowtie2
# Requirements: rsem-prepare-reference, rsem-calculate-expression, bowtie2
#
# Usage:
#   bash 09_rsem_quantification.sh trinity_out_dir/Trinity.fasta data_1_clean.fq.gz data_2_clean.fq.gz

TRINITY_FASTA="${1:-trinity_out_dir/Trinity.fasta}"
R1_CLEAN="${2:-data_1_clean.fq.gz}"
R2_CLEAN="${3:-data_2_clean.fq.gz}"

CPU="${CPU:-16}"
RSEM_REF="${RSEM_REF:-trinity_rsem_ref}"
OUT_PREFIX="${OUT_PREFIX:-data_expression}"

# Prepare RSEM reference
rsem-prepare-reference --bowtie2 "${TRINITY_FASTA}" "${RSEM_REF}"

# Quantify (paired-end)
rsem-calculate-expression --bowtie2 --paired-end -p "${CPU}"   --no-bam-output --output-genome-bam   "${R1_CLEAN}" "${R2_CLEAN}"   "${RSEM_REF}" "${OUT_PREFIX}"

# Main outputs:
#   ${OUT_PREFIX}.genes.results    -> gene-level expression (FPKM/TPM/counts)
#   ${OUT_PREFIX}.isoforms.results -> isoform-level expression
